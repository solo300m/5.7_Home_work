package com.example.MyBookShopApp;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class MyBookShopAppApplicationTests {

	@Test
	void contextLoads() {
	}

}
